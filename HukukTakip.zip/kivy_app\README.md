# Hukuk Takip Uygulaması

Kivy tabanlı hukuk takip uygulaması.

## APK Oluşturma

Bu repository'ye kod push ettiğinizde otomatik olarak APK oluşturulur.

## Kurulum

```bash
pip install kivy
python main.py
```

## APK İndirme

Actions sekmesinden en son build'in APK dosyasını indirebilirsiniz.
